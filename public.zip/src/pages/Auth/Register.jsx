import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import CategoryButtons from '../../components/CategoryButtons/CategoryButtons';
import './Register.css';
import '../../components/CategoryButtons/CategoryButtons.css';

const Register = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Регистрация:', formData);
  };

  return (
    <div className="register-container">
      <div className="categories-section">
        <div className="main-title-container">
          <h1 className="main-title">Закажи и наслаждайся</h1>
        </div>
        
        {/* Передаем пропс для регистрационной версии */}
        <CategoryButtons isRegisterPage={true} />
      </div>

      {/* Правая часть с формой */}
      <div className="form-section">
        {/* Блок заголовка регистрации */}
        <div className="register-header">
          <h2>Регистрация</h2>
          <p>Зарегистрируйтесь, и не упустите самые Горячие скидки!</p>
          <div className="divider"></div>
        </div>

        {/* Форма ввода */}
        <form className="register-form" onSubmit={handleSubmit}>
          <div className="input-group">
            <input
              type="email"
              name="email"
              placeholder='Email'
              value={formData.email}
              onChange={handleChange}
              required
            />
          </div>
          
          <div className="input-group">
            <input
              type="password"
              name="password"
              placeholder='Пароль'
              value={formData.password}
              onChange={handleChange}
              required
            />
          </div>

          {/* Блок кнопки продолжить */}
          <div className="submit-block">
            <button type="submit">Продолжить</button>
            <p>Нажимая на кнопку вы соглашаетесь на обработку Персональных данных</p>
          </div>
        </form>

        {/* Разделитель */}
        <div className="divider divider-with-text">
          <span>Или</span>
        </div>

        {/* Кнопка Google */}
        <button className="google-btn">
          <img src="/image/google.svg" alt="Google" />
          Google
        </button>

        {/* Ссылка на вход */}
        <div className="login-link">
          <span>У вас есть аккаунт?</span>
          <Link to="/login">Войти</Link>
        </div>
      </div>
    </div>
  );
};

export default Register;